package com.example.newchbot

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
