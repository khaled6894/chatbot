import 'dart:async';
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

///  Gemini key
const String _geminiKey = 'AIzaSyCFOlBpKQOlXgDrKCTBZqG_mePD3hU_PSU';
void main() => runApp(const VoiceChatbotApp());

class VoiceChatbotApp extends StatelessWidget {
  const VoiceChatbotApp({super.key});

  @override
  Widget build(BuildContext context) {
    final primary = const Color(0xFF4D7DF1); 

    return MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Voice Chatbot (Gemini)',
    theme: ThemeData(
    brightness: Brightness.dark,
    colorScheme: ColorScheme.fromSeed(
    seedColor: const Color(0xFF3B82F6),
    brightness: Brightness.dark,
    ),
    scaffoldBackgroundColor: const Color(0xFF0F172A), 
    appBarTheme: const AppBarTheme(
    backgroundColor: Color(0xFF0F172A), 
    foregroundColor: Colors.white,  
    surfaceTintColor: Colors.transparent,
    elevation: 0,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
    backgroundColor: Color(0xFF1E40AF),
    foregroundColor: Colors.white,
    padding: EdgeInsets.symmetric(vertical: 14, horizontal: 28),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
    foregroundColor: Colors.white70,
    side: BorderSide(color: Colors.white24),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    ),
    ),
      // الشاشة الرئيسيه
      home: const VoiceHome(),
    );
  }
}

class VoiceHome extends StatefulWidget {
  const VoiceHome({super.key});

  @override
  State<VoiceHome> createState() => _VoiceHomeState();
}

class _VoiceHomeState extends State<VoiceHome> {
  // التعرف على الصوت
  final stt.SpeechToText _speech = stt.SpeechToText();
  //  تحويل النص إلى صوت
  final FlutterTts _tts = FlutterTts();

  bool _listening = false;
  String _status = 'Tap to talk'; // رساله الحاله اسفل الزر
  String _heard = '';           // اخر ما تم سماعه
  String _reply = '';           // رد الذكاء الاصطناعي 

  // استدعاء Gemini API 
  Future<String> _geminiReply(String prompt) async {
    if (_geminiKey.isEmpty) return 'Missing Gemini API key.';
    try {
      final model = GenerativeModel(
        model: 'gemini-1.5-flash',
        apiKey: _geminiKey,
      );
      // نرسل النص للموديل ونحصل على الاستجابة
      final resp = await model.generateContent([Content.text(prompt)]);
      final text = resp.text?.trim();
      return (text == null || text.isEmpty) ? 'No text in response.' : text;
    } on GenerativeAIException catch (e) {
      // أخطاء واجهة Gemini
      return 'Gemini API error: ${e.message}';
    } catch (e) {
      return 'Error: $e';
    }
  }
  @override
  void initState() {
    super.initState();
    _initTts(); // تهيئة إعدادات تحويل النص إلى صوت
  }

  Future<void> _initTts() async {
    await _tts.setLanguage('en-US');        // اللغه
    await _tts.setSpeechRate(0.9);          // سرعة القراءه
    await _tts.setPitch(1.0);               // طبقه الصوت
    await _tts.setVolume(1.0);              // مستوى الصوت
    await _tts.awaitSpeakCompletion(true); 

    try { await _tts.setQueueMode(1); } catch (_) {}
  }

  /// تشغيل/إيقاف لاستماع من الميكروفون
  Future<void> _toggleListen() async {
    if (_listening) {
      await _speech.stop();
      setState(() => _listening = false);
      return;
    }

    final ok = await _speech.initialize(
      onStatus: (s) {
        // توقف الاستماع من النظام
        if (s == 'done' || s == 'notListening') {
          setState(() => _listening = false);
          if (_heard.trim().isNotEmpty) {
            _handleUser(_heard); // رسل ما سمع للذكاء الاصطناعي
          } else {
            setState(() => _status = "Didn't catch that");
          }
        }
      },
      onError: (e) => setState(() {
        _listening = false;
        _status = 'Mic error: ${e.errorMsg}'; // خطا في الميكروفون
      }),
    );

    if (!ok) {
      setState(() => _status = 'Microphone permission denied');
      return;
    }
    // تحديث واجهة الاستخدام
    setState(() {
      _heard = '';
      _reply = '';
      _status = 'Listening...';
      _listening = true;
    });

    // بدء الاستماع لفترة محددة
    await _speech.listen(
      localeId: 'en_US',                         // لغه الاستماع
      listenFor: const Duration(seconds: 8),     // مده الاستماع
      pauseFor: const Duration(seconds: 2),      // مهله التوقف المؤقت
      onResult: (r) => setState(() => _heard = r.recognizedWords), 
    );
  }

  /// نطق الرد كاملاً على دفعات قصيرة لضمان الاستقرار
  Future<void> _speakAll(String text) async {
    await _tts.stop();
    final chunks = _splitIntoChunks(text, 220); // كل جزء 220 حرف
    for (final c in chunks) {
      if (c.trim().isEmpty) continue;
      await _tts.speak(c.trim());
      // فاصلة زمنية بسيطة بين الأجزاء
      await Future.delayed(const Duration(milliseconds: 60));
    }
  }

  /// تقسيم النص إلى جُمل/أجزاء قصيرة (يفيد محرك النطق)
  List<String> _splitIntoChunks(String input, int maxLen) {
    final sentences = input
    .replaceAll('\n', ' ')
    // تدعم . ! ? ؛ ،
    .split(RegExp(r'(?<=[\.\!\?؛،])\s+'));
    final out = <String>[];
    for (var s in sentences) {
    if (s.length <= maxLen) {
    out.add(s);
    } else {
    // في حال كانت الجملة أطول من الحد نقسمها بطول ثابت
    for (var i = 0; i < s.length; i += maxLen) {
    out.add(s.substring(i, (i + maxLen).clamp(0, s.length)));
    }
    }
    }
    return out;
  }

  /// معالجة إدخال المستخدم: استدعاء Gemini ثم عرض/نطق الرد
  Future<void> _handleUser(String text) async {
    setState(() => _status = 'Thinking...');
    final r = await _geminiReply(text);
    setState(() {
    _reply = r;
    _status = 'Tap to talk';
    });
    await _speakAll(r); // نطق الرد على أجزاء
  }

  @override
  void dispose() {
    _speech.stop();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final border = const BorderSide(color: Color(0xFF3B82F6), width: 2);
    final textStyle = const TextStyle(fontSize: 18);

  return Scaffold(
  appBar: AppBar(
  // عنوان التطبيق مع خط سفلي بسيط
  title: const Text(
  'Simple Voice Chatbot',
  style: TextStyle(
  decoration: TextDecoration.underline, 
  decorationThickness: 2,
  ),
  ),
  centerTitle: false,
),
  body: Center(
  child: Padding(
  padding: const EdgeInsets.all(20),
  child: ConstrainedBox(
  constraints: const BoxConstraints(maxWidth: 900),
  child: Column(
  mainAxisAlignment: MainAxisAlignment.start,
  children: [
  const SizedBox(height: 28),

  // --------- صندوق عرض رد الذكاء الاصطناعي ---------
  Container(
  padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 24),
  decoration: BoxDecoration(
  color: const Color(0xFF111827), // خلفية الصندوق (أغمق من الخلفية العامة)
  border: Border.fromBorderSide(border),
  borderRadius: BorderRadius.circular(8),
  ),
  child: Center(
  child: Text(
  _reply.isEmpty
  ? ' '
  : _reply,
  textAlign: TextAlign.center,
  style: textStyle,
  ),
  ),
  ),

  const SizedBox(height: 24),

  // 
  Container(
  width: 380,
  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
  decoration: BoxDecoration(
  color: const Color(0xFF111827),
  border: Border.fromBorderSide(border),
  borderRadius: BorderRadius.circular(8),
  ),
  child: Column(
  children: [

  // زر بدء/إيقاف الاستماع
  ElevatedButton(
  onPressed: _toggleListen,
  child: Text(_listening ? 'Stop' : 'Talk now'),
  ),
  const SizedBox(height: 14),

  // عرض ما قاله المستخدم 
  if (_heard.isNotEmpty) ...[
  const Text('You said:', style: TextStyle(color: Colors.white70)),
  const SizedBox(height: 6),
  Text(_heard,
  textAlign: TextAlign.center,
  style: const TextStyle(fontSize: 16)),
  const SizedBox(height: 8),
  ],


  // رسالة الحالة
  Text(_status, style: const TextStyle(color: Colors.white54)),
  ],
  ),
  ),
  ],
  ),
  ),
  ),
  ),
  );
  }
}